# -*- coding: Utf-8 -*
"""Classes du jeu de Labyrinthe Donkey Kong"""

import pygame
from pygame.locals import *
from constantes import *

class Niveau:
	def __init__(self, fichier):
		self.fichier = "map/"+fichier
		self.structure = 0

	def generer(self):
		"""Méthode permettant de générer le niveau en fonction du fichier.
		On crée une liste générale, contenant une liste par ligne à afficher"""
		#On ouvre le fichier

		with open(self.fichier, "r") as fichier:
			structure_niveau = []
			#On parcourt les lignes du fichier
			for ligne in fichier:
				ligne_niveau = []
				#On parcourt les sprites (lettres) contenus dans le fichier
				for sprite in ligne:
					#On ignore les "\n" de fin de ligne
					if sprite != '\n':
						#On ajoute le sprite à la liste de la ligne
						ligne_niveau.append(sprite)
				#On ajoute la ligne à la liste du niveau
				structure_niveau.append(ligne_niveau)
			#On sauvegarde cette structure
			self.structure = structure_niveau


	def afficher(self, fenetre, dk):
		"""Méthode permettant d'afficher le niveau en fonction
		de la liste de structure renvoyée par generer()"""
		#Chargement des images (seule celle d'arrivée contient de la transparence)
		wall = pygame.image.load(image_wall).convert()
		broken_wall = pygame.image.load(image_broken_wall).convert()
		start = pygame.image.load(image_start).convert()
		bottom_top = pygame.image.load(image_bottom_top).convert()
		left_right = pygame.image.load(image_left_right).convert()
		piece_a = pygame.image.load(image_piece_a).convert_alpha()
		piece_b = pygame.image.load(image_piece_b).convert_alpha()
		piece_c = pygame.image.load(image_piece_c).convert_alpha()
		piece_d = pygame.image.load(image_piece_d).convert_alpha()
		piece_e = pygame.image.load(image_piece_e).convert_alpha()
		piece_a_menu = pygame.image.load(image_piece_a_menu).convert_alpha()
		piece_b_menu = pygame.image.load(image_piece_b_menu).convert_alpha()
		piece_c_menu = pygame.image.load(image_piece_c_menu).convert_alpha()
		piece_d_menu = pygame.image.load(image_piece_d_menu).convert_alpha()
		piece_e_menu = pygame.image.load(image_piece_e_menu).convert_alpha()
		portal = pygame.image.load(image_portal).convert_alpha()
		hammer = pygame.image.load(image_hammer).convert_alpha()
		hammer_menu = pygame.image.load(image_hammer_menu).convert_alpha()
		sword = pygame.image.load(image_sword).convert_alpha()
		sword_menu = pygame.image.load(image_sword_menu).convert_alpha()
		key = pygame.image.load(image_key).convert_alpha()
		big_key = pygame.image.load(image_big_key).convert_alpha()
		gate = pygame.image.load(image_gate).convert_alpha()
		open_gate = pygame.image.load(image_open_gate).convert()
		little_background = pygame.image.load(image_little_background).convert()
		guard = pygame.image.load(image_guard).convert()
		blood = pygame.image.load(image_blood).convert()

		#Item du menu de droite
		if dk.piece_a == True:
			fenetre.blit(piece_a_menu, (459,320))
		if dk.piece_b == True:
			fenetre.blit(piece_b_menu, (499,320))
		if dk.piece_c == True:
			fenetre.blit(piece_c_menu, (459,360))
		if dk.piece_d == True:
			fenetre.blit(piece_d_menu, (499,360))
		if dk.piece_e == True:
			fenetre.blit(piece_e_menu, (479,400))
		if dk.as_key == True:
			fenetre.blit(big_key, (465,50))
		if dk.as_hammer == True:
			fenetre.blit(hammer_menu, (465,125))
		if dk.as_sword == True:
			fenetre.blit(sword_menu, (465,200))

		#On parcourt la liste du niveau
		num_ligne = 0
		for ligne in self.structure:
			#On parcourt les listes de lignes
			num_case = 0
			for sprite in ligne:
				#On calcule la position réelle en pixels
				x = num_case * taille_sprite
				y = num_ligne * taille_sprite
				if sprite == 'w':		   #w = wall
					fenetre.blit(wall, (x,y))
				elif sprite == 'v':		   #v = broken wall
					fenetre.blit(broken_wall, (x,y))
				elif sprite == 's':		   #s = Start
					fenetre.blit(start, (x,y))
				elif sprite == 'N' or sprite == 'S':
					fenetre.blit(bottom_top, (x,y))
				elif sprite == 'E' or sprite == 'W':
					fenetre.blit(left_right, (x,y))
				elif sprite == 'a':		   #a = piece A
					if dk.piece_a == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(piece_a, (x,y))
				elif sprite == 'b':		   #b = piece B
					if dk.piece_b == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(piece_b, (x,y))
				elif sprite == 'c':		   #c = piece C
					if dk.piece_c == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(piece_c, (x,y))
				elif sprite == 'd':		   #d = piece D
					if dk.piece_d == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(piece_d, (x,y))
				elif sprite == 'e':		   #e = piece E
					if dk.piece_e == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(piece_e, (x,y))
				elif sprite == 'j':		   #j = teleport j
					fenetre.blit(portal, (x,y))
					self.portal_j_x = num_case
					self.portal_j_y = num_ligne
				elif sprite == 'i':		   #i = teleport i
					fenetre.blit(portal, (x,y))
					self.portal_i_x = num_case
					self.portal_i_y = num_ligne
				elif sprite == 'k':		   #k = key
					if dk.as_key == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(key, (x,y))
				elif sprite == 'h':		   #h = hammer
					if dk.as_hammer == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(hammer, (x,y))
				elif sprite == 'f':
					if dk.as_sword == True:
						fenetre.blit(little_background, (x,y))
					else:
						fenetre.blit(sword, (x,y))
				elif sprite == 'g':                #g = gate
					if dk.as_key == True:
						fenetre.blit(open_gate, (x,y))
					else:
						fenetre.blit(gate, (x,y))
				elif sprite == 'l':		   #l = guard
					fenetre.blit(guard, (x,y))
				elif sprite == 'm':		   #m = blood
					fenetre.blit(blood, (x,y))
				num_case += 1
			num_ligne += 1

class Perso:
	"""Classe permettant de créer un personnage"""
	def __init__(self, droite, gauche, haut, bas):
		#Sprites du personnage
		self.droite = pygame.image.load(droite).convert_alpha()
		self.gauche = pygame.image.load(gauche).convert_alpha()
		self.haut = pygame.image.load(haut).convert_alpha()
		self.bas = pygame.image.load(bas).convert_alpha()
		#Position du personnage en cases et en pixels
		self.case_x = 7
		self.case_y = 14
		self.x = self.case_x * taille_sprite
		self.y = self.case_y * taille_sprite
		#Direction par défaut
		self.direction_sprite = self.bas
		self.direction = "bas"
		#Items
		self.as_key = False
		self.as_hammer = False
		self.as_sword = False
		self.piece_a = False
		self.piece_b = False
		self.piece_c = False
		self.piece_d = False
		self.piece_e = False
		self.map_name = "c1"

	#Niveau dans lequel le personnage se trouve
	def set_level(self, level):
		self.niveau = level

	#ajout des pieces
	def add_piece(self, piece):
		if piece == 'a':
			self.piece_a = True
		elif piece == 'b':
			self.piece_b = True
		elif piece == 'c':
			self.piece_c = True
		elif piece == 'd':
			self.piece_d = True
		elif piece == 'e':
			self.piece_e = True

	#Reset la position dans un nouveau niveau
	def reset_pos(self, niveau, lvl_from):
		self.niveau = niveau
		if lvl_from == 'E':
			self.case_x = 0
			self.case_y = 7
		if lvl_from == 'W':
			self.case_x = 14
			self.case_y = 7
		if lvl_from == 'N':
			self.case_x = 7
			self.case_y = 0
		if lvl_from == 'S':
			self.case_x = 7
			self.case_y = 14
		self.x = self.case_x * taille_sprite
		self.y = self.case_y * taille_sprite

	def deplacer(self, direction, fenetre):
		"""Methode permettant de déplacer le personnage"""

		#Déplacement vers la droite
		if direction == 'droite':
			#Pour ne pas dépasser l'écran
			if self.case_x < (nombre_sprite_cote - 1):
				if self.niveau.structure[self.case_y][self.case_x+1] == 'W':
					#Déplacement d'une case
					self.case_x += 1
					#Calcul de la position "réelle" en pixel
					self.x = self.case_x * taille_sprite
					if "c" in self.map_name:
						if "1" in self.map_name:
							self.map_name = "w1"
						elif "2" in self.map_name:
							self.map_name = "w2"
						elif "3" in self.map_name:
							self.map_name = "w3"
					if "e" in self.map_name:
						if "1" in self.map_name:
							self.map_name = "c1"
						elif "2" in self.map_name:
							self.map_name = "c2"
				elif self.niveau.structure[self.case_y][self.case_x+1] == 'i':
					self.case_x = self.niveau.portal_j_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_j_y
					self.y = self.case_y * taille_sprite
				elif self.niveau.structure[self.case_y][self.case_x+1] == 'j':
					self.case_x = self.niveau.portal_i_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_i_y
					self.y = self.case_y * taille_sprite
				#On vérifie que la case de destination n'est pas un mur ou une porte sans clé
				elif self.niveau.structure[self.case_y][self.case_x+1] != 'w' and self.niveau.structure[self.case_y][self.case_x+1] != 'v' and self.niveau.structure[self.case_y][self.case_x+1] != 'l':
					if self.niveau.structure[self.case_y][self.case_x+1] == 'g' and self.as_key == True:
						#Déplacement d'une case
						self.case_x += 1
						#Calcul de la position "réelle" en pixel
						self.x = self.case_x * taille_sprite
					elif self.niveau.structure[self.case_y][self.case_x+1] != 'g':
						#Déplacement d'une case
						self.case_x += 1
						#Calcul de la position "réelle" en pixel
						self.x = self.case_x * taille_sprite
			#Image dans la bonne direction
			self.direction_sprite = self.droite
			self.direction = "droite"

		#Déplacement vers la gauche
		if direction == 'gauche':
			if self.case_x > 0:
				if self.niveau.structure[self.case_y][self.case_x-1] == 'E':
					#Déplacement d'une case
					self.case_x -= 1
					#Calcul de la position "réelle" en pixel
					self.x = self.case_x * taille_sprite
					if "c" in self.map_name:
						if "1" in self.map_name:
							self.map_name = "e1"
						elif "2" in self.map_name:
							self.map_name = "e2"
					elif "w" in self.map_name:
						if "1" in self.map_name:
							self.map_name = "c1"
						elif "2" in self.map_name:
							self.map_name = "c2"
						elif "3" in self.map_name:
							self.map_name = "c3"
				elif self.niveau.structure[self.case_y][self.case_x-1] == 'i':
					self.case_x = self.niveau.portal_j_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_j_y
					self.y = self.case_y * taille_sprite
				elif self.niveau.structure[self.case_y][self.case_x-1] == 'j':
					self.case_x = self.niveau.portal_i_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_i_y
					self.y = self.case_y * taille_sprite
				#On vérifie que la case de destination n'est pas un mur ou une porte sans clé
				elif self.niveau.structure[self.case_y][self.case_x-1] != 'w' and self.niveau.structure[self.case_y][self.case_x-1] != 'v' and self.niveau.structure[self.case_y][self.case_x-1] != 'l':
					if self.niveau.structure[self.case_y][self.case_x-1] == 'g' and self.as_key == True:
						#Déplacement d'une case
						self.case_x -= 1
						#Calcul de la position "réelle" en pixel
						self.x = self.case_x * taille_sprite
					elif self.niveau.structure[self.case_y][self.case_x-1] != 'g':
						#Déplacement d'une case
						self.case_x -= 1
						#Calcul de la position "réelle" en pixel
						self.x = self.case_x * taille_sprite
			self.direction_sprite = self.gauche
			self.direction = "gauche"

		#Déplacement vers le haut
		if direction == 'haut':
			if self.case_y > 0:
				if self.niveau.structure[self.case_y-1][self.case_x] == 'N':
					#Déplacement d'une case
					self.case_y -= 1
					#Calcul de la position "réelle" en pixel
					self.y = self.case_y * taille_sprite
					if "c" in self.map_name:
						if "1" in self.map_name:
							self.map_name = "c2"
						elif "2" in self.map_name:
							self.map_name = "c3"
					elif "w" in self.map_name:
						if "1" in self.map_name:
							self.map_name = "w2"
					elif "e" in self.map_name:
						if "1" in self.map_name:
							self.map_name = "e2"
						elif "2" in self.map_name:
							self.map_name = "e3"
						elif "3" in self.map_name:
							self.map_name = "e4"
				elif self.niveau.structure[self.case_y-1][self.case_x] == 'i':
					self.case_x = self.niveau.portal_j_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_j_y
					self.y = self.case_y * taille_sprite
				elif self.niveau.structure[self.case_y-1][self.case_x] == 'j':
					self.case_x = self.niveau.portal_i_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_i_y
					self.y = self.case_y * taille_sprite
				#On vérifie que la case de destination n'est pas un mur ou une porte sans clé
				elif self.niveau.structure[self.case_y-1][self.case_x] != 'w' and self.niveau.structure[self.case_y-1][self.case_x] != 'v' and self.niveau.structure[self.case_y-1][self.case_x] != 'l':
					if self.niveau.structure[self.case_y-1][self.case_x] == 'g' and self.as_key == True:
						self.case_y -= 1
						self.y = self.case_y * taille_sprite
					elif self.niveau.structure[self.case_y-1][self.case_x] != 'g':
						self.case_y -= 1
						self.y = self.case_y * taille_sprite
			self.direction_sprite = self.haut
			self.direction = "haut"

		#Déplacement vers le bas
		if direction == 'bas':
			if self.case_y < (nombre_sprite_cote - 1):
				if self.niveau.structure[self.case_y+1][self.case_x] == 'S':
					#Déplacement d'une case
					self.case_y += 1
					#Calcul de la position "réelle" en pixel
					self.y = self.case_y * taille_sprite
					if "c" in self.map_name:
						if "2" in self.map_name:
							self.map_name = "c1"
						elif "3" in self.map_name:
							self.map_name = "c2"
					elif "e" in self.map_name:
						if "2" in self.map_name:
							self.map_name = "e1"
						elif "3" in self.map_name:
							self.map_name = "e2"
						elif "4" in self.map_name:
							self.map_name = "e3"
					elif "w" in self.map_name:
						if "2" in self.map_name:
							self.map_name = "w1"
				elif self.niveau.structure[self.case_y+1][self.case_x] == 'i':
					self.case_x = self.niveau.portal_j_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_j_y
					self.y = self.case_y * taille_sprite
				elif self.niveau.structure[self.case_y+1][self.case_x] == 'j':
					self.case_x = self.niveau.portal_i_x
					self.x = self.case_x * taille_sprite
					self.case_y = self.niveau.portal_i_y
					self.y = self.case_y * taille_sprite
				#On vérifie que la case de destination n'est pas un mur
				elif self.niveau.structure[self.case_y+1][self.case_x] != 'w' and self.niveau.structure[self.case_y+1][self.case_x] != 'v' and self.niveau.structure[self.case_y+1][self.case_x] != 'l':
					if self.niveau.structure[self.case_y+1][self.case_x] == 'g' and self.as_key == True:
						self.case_y += 1
						self.y = self.case_y * taille_sprite
					elif self.niveau.structure[self.case_y+1][self.case_x] != 'g':
						self.case_y += 1
						self.y = self.case_y * taille_sprite
			self.direction_sprite = self.bas
			self.direction = "bas"
		#Detection de clé
		if self.niveau.structure[self.case_y][self.case_x] == 'k':
			self.as_key = True

		#Detection du marteau
		if self.niveau.structure[self.case_y][self.case_x] == 'h':
			self.as_hammer = True

		#Detection de l'epee
		if self.niveau.structure[self.case_y][self.case_x] == 'f':
			self.as_sword = True
