def afficher():
    return "Hey"
