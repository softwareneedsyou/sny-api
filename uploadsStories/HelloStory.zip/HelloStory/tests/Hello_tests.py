from Hello import hello
import unittest

class TestStringMethods(unittest.TestCase):

    def test_print(self):
        self.assertEqual(hello.afficher(), "Hey")

if __name__ == '__main__':
    unittest.main()