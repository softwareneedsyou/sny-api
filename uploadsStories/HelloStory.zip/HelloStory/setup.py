try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

config = {
    'description': 'Hello',
    'author': 'SNY',
    'url': '',
    'download_url': 'Where to download it.',
    'author_email': 'My email.',
    'version': '0.1',
    'packages': ['Hello'],
    'scripts': [],
    'name': 'Hello'
}

setup(**config)
